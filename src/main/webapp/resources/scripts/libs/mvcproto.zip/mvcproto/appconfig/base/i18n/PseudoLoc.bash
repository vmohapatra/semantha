#!/bin/bash

buildClasspath ()
{
	local LIB=../../../work/Catalina/localhost/semantha/WEB-INF/lib
	local CLASSPATH_LOC
	
	for i in $LIB/*.jar; do
		CLASSPATH_LOC=$CLASSPATH_LOC:$i
	done
	
	# Remove the colon that got added to the start of the classpath string
	CLASSPATH_LOC=`echo $CLASSPATH_LOC | cut -c2-`
	
	CLASSPATH=$CLASSPATH_LOC
}

buildClasspath

if [ $# -eq 2 ]
then
	java -cp $CLASSPATH com.expedia.semantha.util.PseudoLoc messages.properties $1 $2
	exit 0
else
	echo 'Usage: ./PseudoLoc.bash <target-locale> <expansion>'
	exit 1
fi
